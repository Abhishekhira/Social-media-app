import React from 'react'
import Feed from '../../components/feed/Feed'
import ProfileRightbar from './MyprofilrRight'
import Topbar from '../../components/topbar/Topbar'
import './2.css'
import Sidebar from '../../components/sidebar/Sidebar'
const MideSection = () => {
  return (
   <>
   <Topbar />
      <div className="profile">
        <Sidebar />
        <div className="profileRight">
          <div className="profileRightTop">
            <div className="profileCover">
              <img
                className="profileCoverImg"
                src="assets/person/22.jpg"
                alt=""
              />
              <img
                className="profileUserImg"
                src="assets/person/1111.jpg"
                alt=""
              />
            </div>
            <div className="profileInfo">
                <h4 className="profileInfoName">Abhishek Raina</h4>
                <span className="profileInfoDesc">Hello I am A self taught Web developer </span>
            </div>
          </div>
          <div className="profileRightBottom">
          <ProfileRightbar />
            <Feed />
          
          </div>
        </div>
      </div>
   </>
  )
}

export default MideSection