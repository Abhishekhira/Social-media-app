import React from 'react'
import Sidebar from '../../components/sidebar/Sidebar'
import Topbar from '../../components/topbar/Topbar'
import MideSection from './MideSection'
import ProfileRightbar from './MyprofilrRight'
import './pro.css'

const Myprofile = () => {
  return (
   <div style={{displaye:"flex"}}>
   
   <MideSection />
   </div>
   
  )
}

export default Myprofile