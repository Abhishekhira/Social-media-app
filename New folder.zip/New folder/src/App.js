
import Profile from './pages/profile/Profile';

import Myprofile from './pages/profile/Myprofile';
import { Routes, Route} from "react-router-dom"
import Register from './register/Register';
function App() {
  return (
    <>
   <Routes>
   <Route path='/myprofile' element ={<Myprofile />} />
   <Route path="/" element={<Profile />} />
   <Route path='/login' element={<Register />}/>
   </Routes>
  
 

  </>
  );
}

export default App;
