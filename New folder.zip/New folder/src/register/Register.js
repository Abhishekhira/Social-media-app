import "./register.css"
import { Link } from "react-router-dom"

export default function Register(){
    return(
        <div className="login">
        <div className="loginWrapper">
        <div className="loginLeft">
        <Link to="/" style={{textDecoration:"none"}}>
        <h3 className="loginLogo">SocialApp</h3>
        </Link>
        <span className="loginDesc"> Connect with friends and the world around you on socialApp.</span>
        </div>
        <div className="loginright">
        <div className="loginBox">
        <input placeholder="username" className="loginInput" />
        <input placeholder="email" className="loginInput" />
        <input type="password" placeholder="password" className="loginInput" />
        <input type="password" placeholder="password again" className="loginInput" />
        <button className="loginButton">SignUp</button>
       
        <button className="loginRegisterButton">Login into Account</button>
        
        </div>
        </div>
        </div>
        </div>
    )
}