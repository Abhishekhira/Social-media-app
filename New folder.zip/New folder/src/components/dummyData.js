export const Users=[
{
    id:1,
    profilePicture:"assets/person/1.jpeg",
    username:"John"
},
{
    id:2,
    profilePicture:"assets/person/2.jpeg",
    username:"Janell Shrum"
},
{
    id:3,
    profilePicture:"assets/person/3.jpeg",
    username:"alex Durden",
},
{
    id:4,
    profilePicture:"assets/person/4.jpeg",
    username:"Dora Hawks",
},
{
    id:5,
    profilePicture:'assets/person/5.jpeg',
    username:"Thomas holden"
},
{
    id:6,
    profilePicture:"assets/person/6.jpeg",
    username:"shirley Beauchamp",
},
{
    id:7,
    profilePicture:"assets/person/7.jpeg",
    username:"Travis Bennett",
},
{
    id:8,
    profilePicture:"assets/person/8.jpeg",
    username:"Gray Duty",
},
{
    id:9,
    profilePicture:"assets/person/9.jpeg",
    username:"safak kocaoglu",
},
{
    id:10,
    profilePicture:"assets/person/10.jpeg",
    username:"kristen Thomas"
}
];
export const Posts=[
    {
        id:1,
        desc:"Love fr all hatred for none.",
        photo:"assets/post/1.jpeg",
        date:"5 min ago",
        userId:1,
        like:32,
        comment:10,
    },
    {
        id:2,
        photo:"assets/post/2.jpeg",
        date:"2 days ago",
        userId:2,
        like:58,
        comment:19,
    },
    {
        id:3,
        desc:"Every moment is a fresh begining",
        photo:"assets/post/3.jpeg",
        date:"1 hours ago",
        userId:3,
        like:61,
        comment:2,
    },
    {
        id:4,
        photo:"assets/post/4.jpeg",
        date:"4 hours ago",
        userId:4,
        like:7,
        comment:1,
    },
    {
        id:5,
        photo:"assets/post/5.jpeg",
        date:"3 min ago",
        userId:5,
        like:5,
        comment:19,
    },
    {
        id:6,
        photo:"assets/post/6.jpeg",
        date:"5 days ago",
        userId:6,
        like:589,
        comment:119,
    },
    {
        id:7,
        desc:"never regret anythng that made you smile",
        photo:"assets/post/7.jpeg",
        date:"1 days ago",
        userId:7,
        like:5,
        comment:9,
    },
    {
        id:8,
        photo:"assets/post/8.jpeg",
        date:"7 hours ago",
        userId:7,
        like:8,
        comment:2,
    },
    {
        id:9,
        photo:"assets/post/9.jpeg",
        date:"1 week ago ",
        userId:9,
        like:19,
        comment:10,
    },
    {
        id:10,
        photo:"assets/post/10.jpeg",
        date:"1 min ago",
        userId:10,
        like:3,
        comment:1,
    },
];
    