import React from 'react'
import './sidebar.css'
import RssFeed from "@mui/icons-material/RssFeed"
import Chat from "@mui/icons-material/Chat"
import PlayCircleFilledOutlined from "@mui/icons-material/PlayCircleFilledOutlined";
import Group from "@mui/icons-material/Group"
import Bookmark from "@mui/icons-material/Bookmark"
import Helpoutline from "@mui/icons-material/HelpOutline"
import CloseFriend from '../closeFriend/CloseFriend';
import Event from "@mui/icons-material/Event"
import School from "@mui/icons-material/School"
import { Login } from '@mui/icons-material';
import { Link } from 'react-router-dom';


const Sidebar = () => {
  return (
    <div className='sidebar'>
     <div className='sidebarWrapper'>
     <ul className='sidebarList'>
     <li className='sidebarListItem'>
       <RssFeed className='sidebarIcon' />
       <span className='sidebarListItemText'>Feed</span>
     </li>
   
     <li className='sidebarListItem'>
       <Chat className='sidebarIcon'/>
       <span className='sidebarListItemText'>Chat</span>
     </li>
    
     <li className='sidebarListItem'>
       <PlayCircleFilledOutlined className='sidebarIcon' />
       <span className='sidebarListItemText'>Videos</span>
     </li>
     <li className='sidebarListItem'>
      <Group  className='sidebarIcon'/>
       <span className='sidebarListItemText'>Groups</span>
     </li>
     <li className='sidebarListItem'>
       <Bookmark className='sidebarIcon' />
       <span className='sidebarListItemText'>Bookmarks</span>
     </li>
     <li className='sidebarListItem'>
       <Helpoutline className='sidebarIcon'/>
       <span className='sidebarListItemText'>Questions</span>
     </li>
     
     <li className='sidebarListItem'>
       <Event className='sidebarIcon' />
       <span className='sidebarListItemText'>Events</span>
     </li>
     
     <li className='sidebarListItem'>
       <School className='sidebarIcon'/>
       <span className='sidebarListItemText'>Courses</span>
     </li>
    
     
     </ul>
     <button className='sidebarButton'>Show more</button>
     <Link to="/login" style={{textDecoration:"none"}}>
     <button className='sidebarButton' style={{margin:"16px 0",display:"flex",alignItem:"center",fontSize:"1rem",justifyContent:"space-around",cursor:"pointer"}}><Login/>Login</button>
     </Link>
     <hr className='sidebarHr' />
     <ul>
      <CloseFriend />
     </ul>
     </div>
    
    </div>
  )
}

export default Sidebar