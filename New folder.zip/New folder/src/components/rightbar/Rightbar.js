import React from 'react'
import './rightbar.css'
import { Users } from '../dummyData'
import Online from '../online/Online'

const Rightbar = () => {
  return (
   <>
   <div className='rightbar'>
   
   <div className='birthdayContainer'>
   <img  className='birthdayImg' src='assets/gift.png'/>
   <span className='birthdayText'>
   <b>Rahul Shrama</b> and <b> 4 other friends</b>
   have been birthday today,
   </span>
   </div>

 
   <img  className='rightbarAd' src='assets/person/ad.jpg' alt=''/>
   <h4 className='rightbarTitle'>online Friends</h4>
  
   <ul className='rightbarFriendList'>{
    Users.map((u)=> (
      <Online key={u.id} user={u}/>      
    )

  )}</ul>
   
   
   
   </div>
 
   </>
  )
}




export default Rightbar