import React from 'react'
import './closeFriend.css'
const CloseFriend = () => {
  return (
    <>    <li className='sidebarFriend'>
    <img className='sidebarFriendImg' src='./assets/person/1.jpeg' />
    <span className='sidebarfriendname'>Erica</span>
    </li>
    <li className='sidebarFriend'>
    <img className='sidebarFriendImg' src='./assets/person/2.jpeg' />
    <span className='sidebarfriendname'>Max</span>
    </li>
    <li className='sidebarFriend'>
    <img className='sidebarFriendImg' src='./assets/person/3.jpeg' />
    <span className='sidebarfriendname'>Sam</span>
    </li>
    <li className='sidebarFriend'>
    <img className='sidebarFriendImg' src='./assets/person/4.jpeg' />
    <span className='sidebarfriendname'>Alexa</span>
    </li>
    <li className='sidebarFriend'>
    <img className='sidebarFriendImg' src='./assets/person/6.jpeg' />
    <span className='sidebarfriendname'>Eliza</span>
    </li>
    <li className='sidebarFriend'>
    <img className='sidebarFriendImg' src='./assets/person/5.jpeg' />
    <span className='sidebarfriendname'>John</span>
    </li>
    <li className='sidebarFriend'>
    <img className='sidebarFriendImg' src='./assets/person/5.jpeg' />
    <span className='sidebarfriendname'>John</span>
    </li>
    <li className='sidebarFriend'>
    <img className='sidebarFriendImg' src='./assets/person/5.jpeg' />
    <span className='sidebarfriendname'>John</span>
    </li>
    <li className='sidebarFriend'>
    <img className='sidebarFriendImg' src='./assets/person/5.jpeg' />
    <span className='sidebarfriendname'>John</span>
    </li>
    <li className='sidebarFriend'>
    <img className='sidebarFriendImg' src='./assets/person/5.jpeg' />
    <span className='sidebarfriendname'>John</span>
    </li>
  
    </>

  )
}

export default CloseFriend